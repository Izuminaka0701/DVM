# Demo: Hệ thống phát hiện DDoS tầng ứng dụng thời gian thực

Project này hiện thực đúng 5 module ở **Chương 3** và tạo dữ liệu cho **Chương 4**.
Mỗi file code đều có docstring ghi rõ tương ứng với mục nào trong luận văn.

```
ddos_demo/
├── common/features.py          3.3.1, 3.3.2 - đặc trưng + sliding window (dùng chung)
├── app/
│   ├── main.py                 3.1, 3.2, 3.3.2, 3.4.2 - server + collector + vòng lặp
│   ├── inference.py             3.4 - nạp model, suy luận
│   └── alert.py                 3.5 - cảnh báo + debounce + block IP
├── training/
│   ├── generate_dataset.py      3.4.1 - tái tạo cửa sổ offline từ log thô
│   ├── train_offline.py         3.4.1, 4.2 - huấn luyện + so sánh model
│   └── baseline_fixed_threshold.py   4.2, 4.4 - baseline không dùng ML
├── dashboard/dashboard.py       3.6 - giao diện giám sát
├── experiments/
│   ├── locustfile_normal.py     4.1.2 - traffic bình thường
│   ├── locustfile_burst.py      4.1.2 - traffic burst hợp lệ (flash-sale)
│   ├── attack_http_flood.py     4.1.2 - tấn công HTTP flood
│   ├── attack_slowloris.py      4.1.2 - tấn công Slow HTTP (không log được - xem hạn chế)
│   ├── attack_get_flood_variable.py  4.1.2, 4.3.2 - GET flood cường độ tham số hoá
│   ├── attack_slow_post.py      4.1.2, 4.5 - Slow POST (rate thấp, connection lâu)
│   ├── attack_bot_mimicry.py    4.4, 4.5 - bot bắt chước traffic thật (ip_entropy thấp)
│   ├── run_attack_suite.py      điều phối tự động 4 kịch bản trên, tự lưu log có nhãn
│   ├── benchmark_latency.py     4.3.1, 4.3.2, 4.3.3 - đo latency/delay/CPU-RAM
│   └── plot_results.py          sinh hình cho Chương 4
└── requirements.txt
```

## Bước 0 - Cài đặt

```bash
cd ddos_demo
python -m venv venv && source venv/bin/activate
pip install -r requirements.txt
```

## Bước 1 - Chạy server (lúc này chưa có model, dùng luật ngưỡng tạm)

```bash
uvicorn app.main:app --reload --port 8000
```

Kiểm tra: `curl http://localhost:8000/` và `curl http://localhost:8000/metrics/latest`
(đợi ~5s để vòng lặp nền chạy lần đầu).

## Bước 2 - Thu dữ liệu 3 kịch bản để tạo tập huấn luyện (ứng với 4.1.2)

Với **mỗi** kịch bản dưới đây: khởi động lại `app/main.py` (để buffer sạch), chạy
kịch bản traffic trong 1-2 phút, sau đó **đổi tên** `logs/raw_requests.jsonl` để
không bị ghi đè bởi kịch bản tiếp theo.

**Kịch bản A - traffic bình thường:**
```bash
locust -f experiments/locustfile_normal.py --host=http://localhost:8000 -u 20 -r 5 --run-time 90s --headless
mv logs/raw_requests.jsonl logs/raw_requests_normal.jsonl
```

**Kịch bản B - traffic burst hợp lệ (flash-sale, vẫn là nhãn "normal"):**
```bash
locust -f experiments/locustfile_burst.py --host=http://localhost:8000 -u 300 -r 50 --run-time 90s --headless
mv logs/raw_requests.jsonl logs/raw_requests_burst.jsonl
```

**Kịch bản C - tấn công:**
```bash
python experiments/attack_http_flood.py       # hoặc: python experiments/attack_slowloris.py
mv logs/raw_requests.jsonl logs/raw_requests_attack.jsonl
```

### Bước 2b (tuỳ chọn) - Dùng bộ 4 kịch bản tấn công mở rộng tự động

Thay vì chỉ chạy `attack_http_flood.py` / `attack_slowloris.py` thủ công, có thể
chạy tự động 4 kịch bản (GET flood cường độ thấp/cao, Slow POST, bot mimicry):

```bash
python experiments/run_attack_suite.py
```

Script tự lưu log thô có nhãn sẵn vào `logs/raw_requests_attack_*.jsonl`, in ra
luôn lệnh `generate_dataset.py` tương ứng để chạy tiếp. Có đủ 4 kịch bản này giúp
bảng 4.4 phong phú hơn: so sánh detection delay/F1 theo từng LOẠI và CƯỜNG ĐỘ tấn
công, thay vì chỉ 1 con số duy nhất.

## Bước 3 - Sinh tập dữ liệu huấn luyện (3.4.1)

```bash
python training/generate_dataset.py logs/raw_requests_normal.jsonl normal
python training/generate_dataset.py logs/raw_requests_burst.jsonl normal
python training/generate_dataset.py logs/raw_requests_attack.jsonl attack
```

Kết quả: `data/training_data.csv` với 5 cột đặc trưng + nhãn.

## Bước 4 - Huấn luyện & đánh giá offline (3.4.1, 4.2)

```bash
python training/train_offline.py
```

In ra bảng Accuracy/Precision/Recall/F1 cho baseline ngưỡng tĩnh và các mô hình
(RandomForest, MLP, XGBoost nếu đã cài) — copy trực tiếp vào bảng 4.2 của luận văn.
Model tốt nhất được lưu vào `models/model.pkl` + `models/scaler.pkl`.

## Bước 5 - Chạy lại server với model thật + dashboard (3.6)

```bash
uvicorn app.main:app --reload --port 8000
# terminal khác:
streamlit run dashboard/dashboard.py
```

## Bước 6 - Đo hiệu năng định lượng (4.3)

Trong lúc server đang chạy, lấy PID (`pgrep -f "uvicorn app.main"`), rồi ở 1
terminal khác chạy đồng thời traffic (locust hoặc attack script) và:

```bash
python experiments/benchmark_latency.py <PID> 60
```

Sau khi đã chạy đủ các kịch bản (normal / burst / attack) với lệnh trên,
tổng hợp báo cáo:

```bash
python experiments/benchmark_latency.py
python experiments/plot_results.py
```

Kết quả:
- **4.3.1 Processing latency**: in ra mean/P50/P95/max (ms), hình `fig_4_3_1_processing_latency.png`.
- **4.3.2 Detection delay**: thời gian từ lúc tấn công bắt đầu đến cảnh báo đầu tiên,
  đọc từ `logs/attack_start.log` so với `logs/alerts.jsonl`.
- **4.3.3 Resource overhead**: hình `fig_4_3_3_resource_usage.png` (CPU/RAM theo thời gian),
  nên chạy riêng cho 3 trạng thái idle / normal / attack để có bảng so sánh.

## Bước 7 - So sánh với nghiên cứu tiền nhiệm (4.4)

Bảng 4.4 nên gồm 3 dòng: **Baseline ngưỡng tĩnh** (đã có F1 từ Bước 4),
**Hệ thống đề xuất** (F1 từ Bước 4), và **con số từ 1-2 bài báo liên quan**
(lấy từ phần related work đã tổng hợp trước đó) — ghi rõ baseline của họ dùng
dataset gì để người đọc hiểu đây là so sánh tham khảo, không phải cùng điều kiện.

## Bước 8 - Hạn chế cần nêu trong 4.5

- Hệ thống dựa trên request log tầng ứng dụng nên **không bắt được Slowloris
  thật** (kết nối chưa hoàn tất header không được ghi log) — đây là kết quả
  thực nghiệm thật, không phải lỗi, nên trình bày như một phát hiện và hướng
  mở rộng (thêm đặc trưng tầng kết nối).
- Thử nghiệm trên 1 node, traffic mô phỏng bằng Locust/aiohttp/socket thay vì
  traffic thật từ nhiều vùng địa lý.
- IP nguồn khi demo HTTP flood trên 1 máy được giả lập qua header
  `X-Forwarded-For`, không phải nhiều IP thật.

## Ghi chú quan trọng

- **KHÔNG** chạy các attack script nhắm vào server không thuộc quyền sở hữu của bạn.
- Cơ chế "chặn IP" trong `app/alert.py` chỉ ghi log (`logs/blocked_ips.txt`),
  không thực sự đổi firewall — an toàn cho máy demo.
