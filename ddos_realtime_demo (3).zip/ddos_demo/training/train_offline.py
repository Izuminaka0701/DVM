"""
training/train_offline.py
3.4.1 Offline Training Pipeline + 4.2 Đánh giá và lựa chọn mô hình học máy.
So sánh vài mô hình nhẹ (đủ nhanh để suy luận real-time) với baseline ngưỡng tĩnh,
chọn mô hình tốt nhất theo F1-score, lưu model + scaler cho app/inference.py dùng.

Chạy: python training/train_offline.py
"""
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

import joblib  # noqa: E402
import pandas as pd  # noqa: E402
from sklearn.ensemble import RandomForestClassifier  # noqa: E402
from sklearn.metrics import (  # noqa: E402
    accuracy_score,
    confusion_matrix,
    f1_score,
    precision_score,
    recall_score,
)
from sklearn.model_selection import train_test_split  # noqa: E402
from sklearn.neural_network import MLPClassifier  # noqa: E402
from sklearn.preprocessing import StandardScaler  # noqa: E402

from common.features import FEATURE_ORDER  # noqa: E402
from training.baseline_fixed_threshold import fixed_threshold_predict  # noqa: E402

DATA_PATH = Path(__file__).resolve().parent.parent / "data" / "training_data.csv"
MODEL_DIR = Path(__file__).resolve().parent.parent / "models"
MODEL_DIR.mkdir(exist_ok=True)


def evaluate(name, y_true, y_pred):
    print(f"\n--- {name} ---")
    print("Accuracy :", round(accuracy_score(y_true, y_pred), 4))
    print("Precision:", round(precision_score(y_true, y_pred, zero_division=0), 4))
    print("Recall   :", round(recall_score(y_true, y_pred, zero_division=0), 4))
    print("F1-score :", round(f1_score(y_true, y_pred, zero_division=0), 4))
    print("Confusion matrix:\n", confusion_matrix(y_true, y_pred))
    return f1_score(y_true, y_pred, zero_division=0)


def main():
    if not DATA_PATH.exists():
        print(f"Chưa có {DATA_PATH}. Hãy chạy training/generate_dataset.py trước "
              f"(cần cả dữ liệu normal, burst và attack).")
        sys.exit(1)

    df = pd.read_csv(DATA_PATH)
    X = df[FEATURE_ORDER].values
    y = df["label"].values

    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=0.25, random_state=42, stratify=y
    )

    scaler = StandardScaler().fit(X_train)
    X_train_s = scaler.transform(X_train)
    X_test_s = scaler.transform(X_test)

    # Baseline (4.4): rule ngưỡng cố định trên request_rate, dùng dữ liệu thô chưa scale
    baseline_pred = [fixed_threshold_predict(row) for row in X_test]
    baseline_f1 = evaluate("Baseline - Fixed threshold (request_rate)", y_test, baseline_pred)

    candidates = {
        "RandomForest": RandomForestClassifier(n_estimators=200, max_depth=10, random_state=42),
        "MLP": MLPClassifier(hidden_layer_sizes=(32, 16), max_iter=500, random_state=42),
    }
    try:
        from xgboost import XGBClassifier

        candidates["XGBoost"] = XGBClassifier(
            n_estimators=200, max_depth=5, eval_metric="logloss", random_state=42
        )
    except ImportError:
        print("\n(Bỏ qua XGBoost - chạy 'pip install xgboost' nếu muốn thêm vào so sánh)")

    best_name, best_model, best_f1 = None, None, -1
    for name, model in candidates.items():
        model.fit(X_train_s, y_train)
        pred = model.predict(X_test_s)
        f1 = evaluate(name, y_test, pred)
        if f1 > best_f1:
            best_name, best_model, best_f1 = name, model, f1

    print(f"\n=> Mô hình tốt nhất: {best_name} (F1={best_f1:.4f}, baseline F1={baseline_f1:.4f})")

    joblib.dump(best_model, MODEL_DIR / "model.pkl")
    joblib.dump(scaler, MODEL_DIR / "scaler.pkl")
    print(f"Đã lưu model + scaler vào {MODEL_DIR}/ (app/main.py sẽ tự nạp lại khi khởi động)")


if __name__ == "__main__":
    main()
