"""
experiments/run_attack_suite.py
CHỈ dùng để tấn công server localhost trong testbed của chính bạn.

Điều phối tự động: xoá log cũ, chạy lần lượt từng loại tấn công đã build
(get_flood ở 2 mức cường độ, slow_post, bot_mimicry), sau mỗi lần tự động
lưu log thô ra file riêng có nhãn để dùng ngay cho generate_dataset.py.

YÊU CẦU: app/main.py (uvicorn) phải đang chạy sẵn ở localhost:8000 trước khi
chạy script này. Traffic bình thường/burst vẫn chạy riêng bằng Locust theo
README vì locust cần chạy ở chế độ riêng.

Chạy: python experiments/run_attack_suite.py
"""
import shutil
import subprocess
import sys
import time
from pathlib import Path

LOG_DIR = Path(__file__).resolve().parent.parent / "logs"
EXP_DIR = Path(__file__).resolve().parent

SCENARIOS = [
    {"name": "attack_get_flood_low", "cmd": [sys.executable, str(EXP_DIR / "attack_get_flood_variable.py"),
                                              "--concurrency", "50", "--duration", "20"]},
    {"name": "attack_get_flood_high", "cmd": [sys.executable, str(EXP_DIR / "attack_get_flood_variable.py"),
                                               "--concurrency", "400", "--duration", "20"]},
    {"name": "attack_slow_post", "cmd": [sys.executable, str(EXP_DIR / "attack_slow_post.py")]},
    {"name": "attack_bot_mimicry", "cmd": [sys.executable, str(EXP_DIR / "attack_bot_mimicry.py")]},
]


def reset_raw_log():
    raw = LOG_DIR / "raw_requests.jsonl"
    if raw.exists():
        raw.unlink()


def main():
    for scenario in SCENARIOS:
        print(f"\n=== Chạy kịch bản: {scenario['name']} ===")
        reset_raw_log()
        time.sleep(1)
        subprocess.run(scenario["cmd"], check=False)
        time.sleep(2)  # để vòng lặp nền của app/main.py kịp ghi metrics cuối
        target = LOG_DIR / f"raw_requests_{scenario['name']}.jsonl"
        raw = LOG_DIR / "raw_requests.jsonl"
        if raw.exists():
            shutil.copy(raw, target)
            print(f"Đã lưu log thô vào {target}")
        else:
            print(f"CẢNH BÁO: không thấy raw_requests.jsonl sau kịch bản {scenario['name']}")

    print("\nHoàn tất. Chạy tiếp:")
    for scenario in SCENARIOS:
        print(f"  python training/generate_dataset.py logs/raw_requests_{scenario['name']}.jsonl attack")


if __name__ == "__main__":
    main()
