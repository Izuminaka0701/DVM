"""
experiments/locustfile_burst.py
4.1.2 Giả lập lưu lượng tăng đột biến NHƯNG hợp lệ (flash-sale) - dùng để đo
false positive rate của hệ thống (nhiều người dùng thật cùng lúc, không phải tấn công).
Chạy với số user LỚN hơn nhiều so với normal, ví dụ:
    locust -f experiments/locustfile_burst.py --host=http://localhost:8000 -u 300 -r 50
"""
import random

from locust import HttpUser, between, task


class FlashSaleShopper(HttpUser):
    wait_time = between(0.2, 1.0)  # người dùng thao tác nhanh trong đợt sale

    @task(4)
    def view_product(self):
        self.client.get(f"/products/{random.randint(1, 20)}")

    @task(2)
    def add_to_cart(self):
        self.client.post("/cart", params={"product_id": random.randint(1, 20)})

    @task(1)
    def browse_home(self):
        self.client.get("/")
