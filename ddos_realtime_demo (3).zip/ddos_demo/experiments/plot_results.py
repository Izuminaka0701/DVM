"""
experiments/plot_results.py
Sinh biểu đồ cho mục 4.3: boxplot processing latency, line chart CPU/RAM.
Chạy: python experiments/plot_results.py
"""
import json
from pathlib import Path

import matplotlib.pyplot as plt
import pandas as pd

LOG_DIR = Path(__file__).resolve().parent.parent / "logs"
FIG_DIR = Path(__file__).resolve().parent.parent / "figures"
FIG_DIR.mkdir(exist_ok=True)


def plot_latency():
    path = LOG_DIR / "metrics.jsonl"
    if not path.exists():
        print("Chưa có metrics.jsonl")
        return
    rows = [json.loads(line) for line in open(path) if line.strip()]
    df = pd.DataFrame(rows)
    plt.figure(figsize=(6, 4))
    plt.boxplot(df["processing_latency_ms"], vert=True)
    plt.ylabel("Processing latency (ms)")
    plt.title("4.3.1 - Phân bố độ trễ xử lý theo cửa sổ")
    plt.savefig(FIG_DIR / "fig_4_3_1_processing_latency.png", dpi=150)
    plt.close()
    print("Đã lưu fig_4_3_1_processing_latency.png")


def plot_resources():
    path = LOG_DIR / "resource_usage.csv"
    if not path.exists():
        print("Chưa có resource_usage.csv - hãy chạy benchmark_latency.py với pid trước.")
        return
    df = pd.read_csv(path, names=["ts", "cpu", "mem_mb"])
    df["t"] = df["ts"] - df["ts"].min()
    fig, ax1 = plt.subplots(figsize=(7, 4))
    ax1.plot(df["t"], df["cpu"], color="tab:red")
    ax1.set_xlabel("Thời gian (s)")
    ax1.set_ylabel("CPU (%)", color="tab:red")
    ax2 = ax1.twinx()
    ax2.plot(df["t"], df["mem_mb"], color="tab:blue")
    ax2.set_ylabel("RAM (MB)", color="tab:blue")
    plt.title("4.3.3 - Mức tiêu thụ CPU & RAM theo thời gian")
    plt.savefig(FIG_DIR / "fig_4_3_3_resource_usage.png", dpi=150)
    plt.close()
    print("Đã lưu fig_4_3_3_resource_usage.png")


if __name__ == "__main__":
    plot_latency()
    plot_resources()
