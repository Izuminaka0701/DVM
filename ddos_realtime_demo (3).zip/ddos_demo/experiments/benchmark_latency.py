"""
experiments/benchmark_latency.py
4.3 Đánh giá Định lượng Hiệu năng Hệ thống Thời gian thực.

Cách 1 - đo CPU/RAM trong lúc app đang chạy (chạy song song với 1 kịch bản traffic):
    python experiments/benchmark_latency.py <pid_cua_uvicorn> <so_giay_can_do>

Cách 2 - tổng hợp báo cáo latency (4.3.1) + detection delay (4.3.2) từ log đã có:
    python experiments/benchmark_latency.py
"""
import json
import statistics
import sys
import time
from pathlib import Path

import psutil

LOG_DIR = Path(__file__).resolve().parent.parent / "logs"
METRICS_LOG = LOG_DIR / "metrics.jsonl"
ATTACK_LOG = LOG_DIR / "attack_start.log"
RESOURCE_LOG = LOG_DIR / "resource_usage.csv"


def monitor_resources(pid: int, duration_s: int):
    proc = psutil.Process(pid)
    with open(RESOURCE_LOG, "a") as f:
        for _ in range(duration_s):
            cpu = proc.cpu_percent(interval=1.0)
            mem_mb = proc.memory_info().rss / (1024 * 1024)
            f.write(f"{time.time()},{cpu},{mem_mb}\n")
    print(f"Đã ghi {duration_s} mẫu CPU/RAM vào {RESOURCE_LOG}")


def summarize_latency():
    if not METRICS_LOG.exists():
        print("Chưa có metrics.jsonl - hãy chạy app/main.py trước.")
        return
    latencies = []
    with open(METRICS_LOG) as f:
        for line in f:
            if line.strip():
                latencies.append(json.loads(line)["processing_latency_ms"])
    if latencies:
        latencies.sort()
        print("\n--- 4.3.1 Processing latency (ms/window) ---")
        print("Mean :", round(statistics.mean(latencies), 3))
        print("P50  :", round(statistics.median(latencies), 3))
        print("P95  :", round(latencies[int(len(latencies) * 0.95)], 3))
        print("Max  :", round(max(latencies), 3))


def summarize_detection_delay():
    if not ATTACK_LOG.exists():
        print("Chưa có attack_start.log - hãy chạy 1 attack script trước.")
        return
    alerts_path = LOG_DIR / "alerts.jsonl"
    alerts = []
    if alerts_path.exists():
        with open(alerts_path) as f:
            alerts = [json.loads(line) for line in f if line.strip()]

    print("\n--- 4.3.2 Detection delay (giây) ---")
    with open(ATTACK_LOG) as f:
        for line in f:
            if not line.strip():
                continue
            name, ts_str = line.strip().split("\t")
            attack_ts = float(ts_str)
            following = [a["ts"] for a in alerts if a["ts"] >= attack_ts]
            if following:
                print(f"{name}: {round(following[0] - attack_ts, 2)}s")
            else:
                print(f"{name}: KHÔNG có cảnh báo nào được ghi nhận sau khi tấn công bắt đầu")


def main():
    if len(sys.argv) == 3:
        monitor_resources(int(sys.argv[1]), int(sys.argv[2]))
    else:
        summarize_latency()
        summarize_detection_delay()


if __name__ == "__main__":
    main()
