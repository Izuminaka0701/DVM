"""
experiments/locustfile_normal.py
4.1.2 Giả lập lưu lượng người dùng bình thường (duyệt web thong thả).
Chạy: locust -f experiments/locustfile_normal.py --host=http://localhost:8000 -u 20 -r 5
"""
import random

from locust import HttpUser, between, task


class NormalShopper(HttpUser):
    wait_time = between(2, 6)  # người thật duyệt web thong thả

    @task(3)
    def browse_home(self):
        self.client.get("/")

    @task(5)
    def view_product(self):
        self.client.get(f"/products/{random.randint(1, 50)}")

    @task(1)
    def add_to_cart(self):
        self.client.post("/cart", params={"product_id": random.randint(1, 50)})
