"""
dashboard/dashboard.py
3.6 Giao diện Giám sát Lưu lượng.
Chạy (trong lúc app/main.py đang chạy): streamlit run dashboard/dashboard.py
"""
import json
import time
from pathlib import Path

import pandas as pd
import streamlit as st

LOG_DIR = Path(__file__).resolve().parent.parent / "logs"
METRICS_LOG = LOG_DIR / "metrics.jsonl"
ALERTS_LOG = LOG_DIR / "alerts.jsonl"

st.set_page_config(page_title="DDoS Real-time Monitor", layout="wide")
st.title("Giám sát lưu lượng thời gian thực")

placeholder = st.empty()


def load_jsonl(path, max_rows=300):
    if not path.exists():
        return pd.DataFrame()
    with open(path) as f:
        lines = f.readlines()[-max_rows:]
    rows = [json.loads(line) for line in lines if line.strip()]
    return pd.DataFrame(rows)


while True:
    metrics_df = load_jsonl(METRICS_LOG)
    alerts_df = load_jsonl(ALERTS_LOG, max_rows=50)

    with placeholder.container():
        if metrics_df.empty:
            st.info("Chưa có dữ liệu - hãy chạy app/main.py và gửi traffic vào trước.")
        else:
            metrics_df["time"] = pd.to_datetime(metrics_df["ts"], unit="s")
            col1, col2 = st.columns(2)
            with col1:
                st.subheader("Request rate (req/s)")
                st.line_chart(metrics_df.set_index("time")["request_rate"])
                st.subheader("IP entropy")
                st.line_chart(metrics_df.set_index("time")["ip_entropy"])
            with col2:
                st.subheader("Xác suất tấn công")
                st.line_chart(metrics_df.set_index("time")["attack_probability"])
                st.subheader("Processing latency (ms)")
                st.line_chart(metrics_df.set_index("time")["processing_latency_ms"])

            st.subheader("Cảnh báo gần đây")
            if not alerts_df.empty:
                st.dataframe(alerts_df.tail(20))
            else:
                st.write("Chưa có cảnh báo nào.")

    time.sleep(2)
    st.rerun()
